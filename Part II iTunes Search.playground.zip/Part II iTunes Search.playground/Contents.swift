import UIKit

struct StoreItem: Codable {
    let name: String?
    let artist: String?
    var kind: String?
    var description: String?
    var artworkURL: URL?

    enum CodingKeys: String, CodingKey {
        case name = "trackName"
        case artist = "artistName"
        case kind
        case description = "longDescription"
        case artworkURL = "artworkUrl100"
    }
}

struct SearchResponse: Codable {
    let results: [StoreItem]
}

enum StoreItemError: Error, LocalizedError {
    case itemsNotFound
    case decodingError
}

func fetchStoreItems(matching query: [String: String]) async throws -> [StoreItem] {
    var urlComponents = URLComponents(string: "https://itunes.apple.com/search")!
    urlComponents.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }

    let (data, response) = try await URLSession.shared.data(from: urlComponents.url!)

    guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
        throw StoreItemError.itemsNotFound
    }

    let decoder = JSONDecoder()
    let searchResponse = try decoder.decode(SearchResponse.self, from: data)

    return searchResponse.results

}

let query: [String: String] = [
    "term": "Apple",
    "media": "ebook",
    "attribute": "authorTerm",
    "lang": "en_us",
    "limit": "10"
]

Task {
    do {
        let storeItems = try await fetchStoreItems(matching: query)
        storeItems.forEach { item in
            print("""
            Name: \(item.name ?? "N/A")
            Artist: \(item.artist ?? "N/A")
            Kind: \(item.kind ?? "N/A")
            Description: \(item.description ?? "N/A")
            Artwork URL: \(item.artworkURL?.absoluteString ?? "N/A")
            
            """)
        }
    } catch {
        print("Error: \(error.localizedDescription)")
    }
}
