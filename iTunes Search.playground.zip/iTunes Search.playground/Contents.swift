import UIKit

struct StoreItem {
    
}
extension Data {
    func prettyPrintedJSONString() {
        guard
            let jsonObject = try?
               JSONSerialization.jsonObject(with: self,
               options: []),
            let jsonData = try?
               JSONSerialization.data(withJSONObject:
               jsonObject, options: [.prettyPrinted]),
            let prettyJSONString = String(data: jsonData,
               encoding: .utf8) else {
                print("Failed to read JSON Object.")
                return
        }
        print(prettyJSONString)
    }
}
let queryDictionary: [String: String] = [
    "term": "Apple",
    "media": "music",
    "limit": "1",
    
]
let baseURLString = "https://itunes.apple.com/search"
var urlComponents = URLComponents(string: baseURLString)
urlComponents?.queryItems = queryDictionary.map {
    URLQueryItem(name: $0.key, value: $0.value)
}
if let finalURL = urlComponents?.url {
    print(finalURL.absoluteString)
    
    
    Task {
        do {
            // Fetch data from the web
            let (data, response) = try await URLSession.shared.data(from: finalURL)
            
            // Check if the response is valid (e.g., status code 200)
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
            
                    data.prettyPrintedJSONString()
        } else {
                    print("Error: Invalid response")
                    // Handle the error as needed
                    return
                }
                
                // Convert the data to a string for display
                if let dataString = String(data: data, encoding: .utf8) {
                    // Print the data string to the console
                    print(dataString)
                } else {
                    print("Error: Unable to convert data to string")
                    // Handle the error as needed
                }
            } catch {
                print("Error: \(error)")
                // Handle the error as needed
            }
        }
    } else {
        print("Error: Unable to create URL")
    }
